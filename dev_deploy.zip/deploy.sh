export DEPLOY_EUREKA_APPS=$DEPLOY_SERVER_IP_2:8761/eureka/apps
echo $DEPLOY_EUREKA_APPS

# Раскомментировать для импорта локальных настроек
#source local-env.sh

set -x
cd "$(dirname "$0")"

# Останавливаем контейнеры
./stop.sh

# Чистим ресурсы стендов
./../common/dev_qa/docker-clean.sh

# Удаляем старые директорию с конфигами
echo "Удаляем старые директории с конфигами на $DEPLOY_SERVER_IP_1"
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_1_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1 -tt "rm -rf /opt/calculation-module-client" || true
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_1_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1 -tt "rm -rf /opt/ignite" || true
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_1_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1 -tt "rm -rf /opt/kafka" || true
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_1_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1 -tt "rm -rf /opt/mq" || true

echo "Удаляем старые директории с конфигами на $DEPLOY_SERVER_IP_2"
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_2_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2 -tt "rm -rf /opt/nvpsv-config-properties" || true
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_2_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2 -tt "rm -rf /opt/kafka" || true

echo "Удаляем старые директории с конфигами на $DEPLOY_SERVER_IP_3"
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_3_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3 -tt "rm -rf /opt/ignite" || true
sshpass -p "$DEPLOY_SERVER_PASSWORD" ssh -p $DEPLOY_3_PORT -oStrictHostKeyChecking=no $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3 -tt "rm -rf /opt/kafka" || true

# Копируем пропирти
echo "Копируем новые директории с конфигами на $DEPLOY_SERVER_IP_1"
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r VM_1/ignite $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r VM_1/calculation-module-client $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r VM_1/kafka $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r VM_1/mq $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r jmx_prometheus_javaagent.jar $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt/kafka
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r config.yml $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt/kafka
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_1_PORT -oStrictHostKeyChecking=no -r zookeeper.yml $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_1:/opt/kafka

echo "Копируем новые директории с конфигами на $DEPLOY_SERVER_IP_2"
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_2_PORT -oStrictHostKeyChecking=no -r ./../../../nvpsv-config-properties $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_2_PORT -oStrictHostKeyChecking=no -r VM_2/kafka $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_2_PORT -oStrictHostKeyChecking=no -r jmx_prometheus_javaagent.jar $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2:/opt/kafka
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_2_PORT -oStrictHostKeyChecking=no -r config.yml $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2:/opt/kafka
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_2_PORT -oStrictHostKeyChecking=no -r zookeeper.yml $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_2:/opt/kafka


echo "Копируем новые директории с конфигами на $DEPLOY_SERVER_IP_3"
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_3_PORT -oStrictHostKeyChecking=no -r VM_3/ignite $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_3_PORT -oStrictHostKeyChecking=no -r VM_3/kafka $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3:/opt
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_3_PORT -oStrictHostKeyChecking=no -r jmx_prometheus_javaagent.jar $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3:/opt/kafka
sshpass -p "$DEPLOY_SERVER_PASSWORD" scp -P$DEPLOY_3_PORT -oStrictHostKeyChecking=no -r config.yml $DEPLOY_SERVER_USER@$DEPLOY_SERVER_IP_3:/opt/kafka


# Пулим новые версии образов
docker login -u $REGISTRY_USER -p $REGISTRY_PASSWORD $REGISTRY
echo "Пулим новые версии образов на $DEPLOY_DOCKER_1"
docker-compose -f VM_1/docker-compose.yml -H $DEPLOY_DOCKER_1 pull
echo "Пулим новые версии образов на $DEPLOY_DOCKER_2"
docker-compose -f VM_2/docker-compose.yml -H $DEPLOY_DOCKER_2 pull
echo "Пулим новые версии образов на $DEPLOY_DOCKER_3"
docker-compose -f VM_3/docker-compose.yml -H $DEPLOY_DOCKER_3 pull

# поднимаем контейнеры
./start.sh

# проверяем запуск сервисов
./../common/dev_qa/check-service.sh
