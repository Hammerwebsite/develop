#Параметры окружения из gitlab ci.
#Раскоментировать и актуализировать при локальном запуске для отладки на dev  
#Требуется подключение к vpn
#export PROFILES=dev
#export DEV_DOCKER_PORT=20000
#export DEV_DOCKER_1=10.155.56.143:$DEV_DOCKER_PORT
#export DEV_DOCKER_2=10.155.56.186:$DEV_DOCKER_PORT
#export DEV_DOCKER_3=10.155.56.120:$DEV_DOCKER_PORT
#export DEPLOY_DOCKER_1=$DEV_DOCKER_1
#export DEPLOY_DOCKER_2=$DEV_DOCKER_2
#export DEPLOY_DOCKER_3=$DEV_DOCKER_3
##для диплоя latest тега
#export TAG=latest 

#Раскоментировать и актуализировать при локальном запуске для отладки на qa
#export QA_SERVER_IP=195.208.201.138
#export PROFILES=qa
#export QA_DOCKER_1=$QA_SERVER_IP:5002
#export QA_DOCKER_2=$QA_SERVER_IP:5003
#export QA_DOCKER_3=$QA_SERVER_IP:5004  
#export DEPLOY_DOCKER_1=$QA_DOCKER_1
#export DEPLOY_DOCKER_2=$QA_DOCKER_2
#export DEPLOY_DOCKER_3=$QA_DOCKER_3
##для остановки всегда можно использовать latest
#export TAG=latest


#echo on
set -x
cd "$(dirname "$0")"
#названия проекта, используется для работы с контейнерами с разных docker-compose.yml 
export project_name=dev

# Останавливаем контейнеры
echo "Останавливаем сервисы на $DEPLOY_DOCKER_1"
docker-compose -f VM_1/docker-compose.yml -H $DEPLOY_DOCKER_1 -p $project_name-nvpsv down || true
echo "Останавливаем mq на $DEPLOY_DOCKER_1"
docker-compose -f VM_1/mq/docker-compose.yml -H $DEPLOY_DOCKER_1 -p $project_name-mq down || true
echo "Останавливаем kafka на $DEPLOY_DOCKER_1"
docker-compose -f VM_1/kafka/docker-compose.yml -H $DEPLOY_DOCKER_1 -p $project_name-kafka down || true

echo "Останавливаем сервисы на $DEPLOY_DOCKER_2"
docker-compose -f VM_2/docker-compose.yml -H $DEPLOY_DOCKER_2 -p $project_name-nvpsv down || true
echo "Останавливаем kafka на $DEPLOY_DOCKER_2"
docker-compose -f VM_2/kafka/docker-compose.yml -H $DEPLOY_DOCKER_2 -p $project_name-kafka down || true

echo "Останавливаем сервисы на $DEPLOY_DOCKER_3"
docker-compose -f VM_3/docker-compose.yml -H $DEPLOY_DOCKER_3 -p $project_name-nvpsv down || true
echo "Останавливаем kafka на $DEPLOY_DOCKER_3"
docker-compose -f VM_3/kafka/docker-compose.yml -H $DEPLOY_DOCKER_3 -p $project_name-kafka down || true

#echo off
set +x
